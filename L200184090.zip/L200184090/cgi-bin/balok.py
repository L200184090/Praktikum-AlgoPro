print '<!DOCTYPE html>'
print
print '''<html>
<head>
\t\t<title>Balok</title>
</head>
<body>

<script type="text/javascript">
\t\tfunction area(){
\t\t\t\tvar p = parseInt(document.getElementById('pj').value);
\t\t\t\t\t\tl = parseInt(document.getElementById('lb').value);
\t\t\t\t\t\tt = parseInt(document.getElementById('tg').value);
\t\t\t\t\t\tarea = (2*(p*l)) + (2*(l*t)) + (2*(p*t));
\t\t\t\tdocument.getElementById('luas').innerHTML = "Luas: "+area;
\t\t}
</script>

<table>
\t\t<tr>
\t\t\t\t<td>
\t\t\t\t\t\t<img src="balok.jpeg" width="100px" height="auto">
\t\t\t\t</td>
\t\t\t\t<td>
\t\t\t\t\t\t<h3>Bangun Geometri</h3><br>
\t\t\t\t\t\tNama bangun: Balok<br>
\t\t\t\t\t\tDimensi: 3D (3 Dimensi)<br>
\t\t\t\t\t\tPanjang: <input type='number' id='pj' min='1'><br>
\t\t\t\t\t\tLebar: <input type='number' id='lb' min='1'><br>
\t\t\t\t\t\tTinggi: <input type='number' id='tg' min='1'><br>
\t\t\t\t\t\t<p id='luas'>Luas:</p>
\t\t\t\t\t\t<button onclick="area()">Hitung Luas</button>
\t\t\t\t</td>
\t\t</tr>
</table></body></html>'''
