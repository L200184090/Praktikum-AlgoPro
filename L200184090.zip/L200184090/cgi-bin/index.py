print "<!DOCTYPE html>"
print
print """<html>
<head>
\t\t<title>Data diri</title>
</head>
<body>
<table>
\t\t<tr>
\t\t\t\t<td></td>
\t\t\t\t<td><h3>Data diri</h3></td>
\t\t</tr>
\t\t<tr>
\t\t\t\t<td><img src="rif.jpg" width="100px" height="auto" alt="Rifqy's photo"></td>
\t\t\t\t<td>
\t\t\t\t\t\tNama: Muhammad Rifqy Fauzy<br>
\t\t\t\t\t\tAlamat: Gonilan<br>
\t\t\t\t\t\tTempat, tangal lahir: Bengkulu, 4 Agustus 2000<br>
\t\t\t\t\t\tTempat wisata favorit: Istano Pagaruyuang<br>
\t\t\t\t\t\tMotto: When you think you're the best, you're the worst
\t\t\t\t</td>
\t\t</tr>"""
print "</table></body></html>"
